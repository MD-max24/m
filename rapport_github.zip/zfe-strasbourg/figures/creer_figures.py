"""Figures du rapport ZFE. Usage : python figures/creer_figures.py data/clean/base_zfe_station_jour.csv figures"""
import sys, pathlib, warnings
import numpy as np, pandas as pd, pyfixest as pf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
warnings.filterwarnings("ignore")

SRC, OUT = sys.argv[1], pathlib.Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
BLEU, ORANGE, ROUGE = "#2a78d6", "#eb6834", "#c0392b"
ENCRE, ENCRE2, GRILLE, FOND = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": GRILLE,
                     "axes.labelcolor": ENCRE2, "xtick.color": ENCRE2, "ytick.color": ENCRE2,
                     "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
                     "grid.color": GRILLE, "grid.linewidth": 0.6, "figure.facecolor": FOND,
                     "axes.facecolor": FOND, "savefig.facecolor": FOND})
pct = lambda x: 100 * (np.exp(x) - 1)

b = pd.read_csv(SRC, parse_dates=["date"])
b = b[(b.panel_complet == 1) & (b.a_exclure == 0)].copy()
d = b[b.exclu == 0].dropna(subset=["vent", "temp", "pluie"]).copy()
for k, ph in {"p1": "P1_pedagogique", "p2": "P2_interdiction_c5", "p3": "P3_interdiction_c4"}.items():
    d["s_" + k] = ((d.phase == ph) & (d.traite == 1)).astype(int)
d["log_no2"] = np.log(d.no2); d["log_no"] = np.log(d.no); d["log_no2_pointe"] = np.log(d.no2_pointe)
d["date_fe"] = d.date.dt.strftime("%Y-%m-%d")
CTRL = " + vent + temp + pluie"

def estime(data, y="log_no2", ctrl=CTRL, fe="station + date_fe", phases=("s_p1", "s_p2", "s_p3")):
    m = pf.feols(f"{y} ~ {' + '.join(phases)}{ctrl} | {fe}", data=data.dropna(subset=[y]), vcov={"CRV1": "station"})
    c, V, n = m.coef(), m._vcov, list(m.coef().index)
    i1, i2 = n.index("s_p1"), n.index("s_p2")
    return c["s_p2"] - c["s_p1"], np.sqrt(V[i2, i2] + V[i1, i1] - 2 * V[i1, i2])

def bandes(ax):
    for a, z, lab in [("2020-03-01", "2021-06-30", "Covid (exclu)")]:
        ax.axvspan(pd.Timestamp(a), pd.Timestamp(z), color="#efeeea", zorder=0)
    for x, lab in [("2022-01-01", "ZFE en vigueur"), ("2023-01-01", "Crit'Air 5 interdits"), ("2024-01-01", "Crit'Air 4 interdits")]:
        ax.axvline(pd.Timestamp(x), color=ENCRE2, lw=0.8, ls=(0, (3, 3)), zorder=1)

# ---------- Figure 1 : NO2 mensuel, Strasbourg vs témoins ----------
tout = b.copy()
tout["mois"] = tout.date.dt.to_period("M").dt.to_timestamp()
mens = tout.groupby(["type", "traite", "station", "mois"]).no2.mean().reset_index()
mens = mens.groupby(["type", "traite", "mois"]).no2.mean().reset_index()
mens.loc[(mens.mois >= "2020-03-01") & (mens.mois <= "2021-06-30"), "no2"] = np.nan

fig, axes = plt.subplots(1, 2, figsize=(12, 4.2), sharey=False)
for ax, t, titre in zip(axes, ["trafic", "fond"], ["Stations trafic", "Stations de fond urbain"]):
    bandes(ax)
    for tr, col, lab in [(1, BLEU, "Strasbourg"), (0, ORANGE, "Moyenne Metz, Nancy, Mulhouse")]:
        s = mens[(mens.type == t) & (mens.traite == tr)]
        ax.plot(s.mois, s.no2, color=col, lw=2, label=lab)
    ax.set_title(titre, loc="left", color=ENCRE, fontsize=11, fontweight="bold")
    ax.set_ylabel("NO₂ moyen mensuel (µg/m³)")
    ax.set_ylim(bottom=0)
    ax.xaxis.set_major_locator(mdates.YearLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
axes[0].text(pd.Timestamp("2020-10-15"), axes[0].get_ylim()[1] * 0.95, "Covid\n(exclu)", ha="center", va="top", color=ENCRE2, fontsize=8)
for x, lab in [("2022-01-01", "ZFE"), ("2023-01-01", "C5"), ("2024-01-01", "C4")]:
    axes[0].text(pd.Timestamp(x), axes[0].get_ylim()[1] * 0.99, " " + lab, color=ENCRE2, fontsize=8, va="top")
axes[0].legend(frameon=False, loc="lower left", fontsize=9)
fig.suptitle("NO₂ mensuel à Strasbourg et dans les villes témoins, 2017-2024", x=0.01, ha="left", fontsize=13, color=ENCRE, fontweight="bold")
fig.text(0.01, -0.02, "Source : EEA (mesures validées E1a), 11 stations du plan d'analyse. Moyenne des stations de chaque groupe. "
         "Pointillés : ZFE en vigueur (2022), interdiction Crit'Air 5 (2023), Crit'Air 4 (2024).", color=ENCRE2, fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig1_no2_mensuel.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 2 : event study ----------
annees = [2017, 2018, 2020, 2021, 2022, 2023, 2024]
for a in annees:
    d[f"s_{a}"] = ((d.annee == a) & (d.traite == 1)).astype(int)
es = pf.feols("log_no2 ~ " + " + ".join(f"s_{a}" for a in annees) + CTRL + " | station + date_fe",
              data=d.dropna(subset=["log_no2"]), vcov={"CRV1": "station"})
t = es.tidy().loc[[f"s_{a}" for a in annees], ["Estimate", "Std. Error"]]
est = pd.DataFrame({"annee": annees, "c": t.Estimate.values, "se": t["Std. Error"].values})
est = pd.concat([est, pd.DataFrame({"annee": [2019], "c": [0.0], "se": [0.0]})]).sort_values("annee")
est.to_csv(OUT / "event_study.csv", index=False)

fig, ax = plt.subplots(figsize=(9, 4.8))
ax.axhline(0, color=ENCRE2, lw=1)
ax.axvspan(2021.5, 2024.6, color="#eef4fc", zorder=0)
ax.text(2021.6, 9.5, "Après l'entrée en vigueur de la ZFE", color=BLEU, fontsize=9, va="top")
for _, r in est.iterrows():
    lo, hi = pct(r.c - 1.96 * r.se), pct(r.c + 1.96 * r.se)
    ax.plot([r.annee, r.annee], [lo, hi], color=ENCRE2, lw=1.5, solid_capstyle="round")
    plein = r.annee != 2019
    ax.plot(r.annee, pct(r.c), "o", ms=9, mfc=BLEU if plein else FOND, mec=BLEU, mew=2, zorder=3)
    lab = "réf." if r.annee == 2019 else f"{pct(r.c):+.1f} %"
    ax.annotate(lab, (r.annee, pct(r.c)), xytext=(10, 0), textcoords="offset points", va="center", fontsize=9, color=ENCRE)
ax.set_xticks(range(2017, 2025))
ax.set_xticklabels(["2017", "2018", "2019", "2020\n(janv.-fév.)", "2021\n(juil.-nov.)", "2022\npédagogique", "2023\nCrit'Air 5", "2024\nCrit'Air 4"])
ax.set_ylabel("Écart Strasbourg vs témoins (%, réf. 2019)")
ax.set_ylim(-25, 30)
ax.set_title("Event study : Strasbourg décroche dès fin 2021, creux en 2022", loc="left", fontsize=12, fontweight="bold", color=ENCRE)
fig.text(0.01, -0.03, "Différence de différences, effets fixes station et date, contrôles vent, température, pluie. "
         "Barres : IC 95 % (grappes = 11 stations), indicatifs.", color=ENCRE2, fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig2_event_study.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 3 : placebos ----------
effet, se_effet = estime(d)
p0 = b[(b.date <= "2019-12-31")].dropna(subset=["vent", "temp", "pluie"]).copy()
p0["log_no2"] = np.log(p0.no2); p0["date_fe"] = p0.date.dt.strftime("%Y-%m-%d")
pl = []
for D in pd.date_range("2018-01-01", "2019-01-01", freq="MS"):
    w = p0[(p0.date >= D - pd.DateOffset(months=12)) & (p0.date < D + pd.DateOffset(months=12))]
    w = w[(w.date < D - pd.Timedelta(days=15)) | (w.date > D + pd.Timedelta(days=15))].copy()
    w["x"] = ((w.date >= D) & (w.traite == 1)).astype(int)
    pl.append(pf.feols("log_no2 ~ x" + CTRL + " | station + date_fe", data=w.dropna(subset=["log_no2"])).coef()["x"])
pl = np.array(pl); mde = 2.8 * pl.std(ddof=1)

fig, ax = plt.subplots(figsize=(9, 3.4))
ax.axvspan(pct(-mde), pct(mde), color="#efeeea", zorder=0)
ax.text(0, 1.55, f"± effet minimum détectable ({pct(mde):.1f} %)", ha="center", color=ENCRE2, fontsize=8)
ax.axvline(0, color=ENCRE2, lw=0.8, ls=(0, (3, 3)))
jit = np.linspace(-0.25, 0.25, len(pl))
ax.scatter(pct(pl), 1 + jit[np.argsort(np.argsort(pl))] * 0, s=60, color="#8a8984", zorder=3, label="13 fausses ruptures (2018-2019)")
ax.scatter([pct(effet)], [1], s=110, color=ROUGE, zorder=4, label="Effet estimé : 2023 vs 2022")
ax.annotate(f"+{pct(effet):.1f} %", (pct(effet), 1), xytext=(0, 12), textcoords="offset points", ha="center", color=ROUGE, fontweight="bold")
ax.set_yticks([]); ax.set_ylim(0.5, 1.7); ax.set_xlim(-8, 10)
ax.set_xlabel("Saut de l'écart Strasbourg vs témoins (%)")
ax.grid(axis="y", visible=False)
ax.legend(frameon=False, loc="lower right", fontsize=9)
ax.set_title("Placebos : l'effet estimé sort de la variabilité habituelle, mais dans le sens d'une hausse", loc="left", fontsize=11, fontweight="bold", color=ENCRE)
fig.text(0.01, -0.06, f"p-valeur placebo = 1/14 ≈ 0,07. Les placebos sont centrés sur {pct(pl.mean()):.1f} % et non sur 0 : "
         "Strasbourg baissait déjà légèrement plus vite que les témoins en 2017-2019.", color=ENCRE2, fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig3_placebos.png", dpi=200, bbox_inches="tight"); plt.close(fig)

# ---------- Figure 4 : robustesse ----------
d["mois"] = d.date.dt.to_period("M").astype(str)
g = d.groupby(["station", "traite", "mois", "phase"]).agg(n=("no2", lambda x: x.notna().sum()), no2=("no2", "mean"),
      vent=("vent", "mean"), temp=("temp", "mean"), pluie=("pluie", "mean")).reset_index()
g["jm"] = pd.PeriodIndex(g.mois, freq="M").days_in_month
g = g[g.n >= 0.75 * g.jm].copy()
for k, ph in {"p1": "P1_pedagogique", "p2": "P2_interdiction_c5", "p3": "P3_interdiction_c4"}.items():
    g["s_" + k] = ((g.phase == ph) & (g.traite == 1)).astype(int)
g["log_no2"] = np.log(g.no2)
tests = [("Modèle principal", estime(d)),
         ("R1 stations trafic", estime(d[d.type == "trafic"])),
         ("R1 stations de fond", estime(d[d.type == "fond"])),
         ("R2 sans Metz", estime(d[d.ville != "Metz"])),
         ("R2 sans Nancy", estime(d[d.ville != "Nancy"])),
         ("R2 sans Mulhouse", estime(d[d.ville != "Mulhouse"])),
         ("R3 sans météo", estime(d, ctrl="")),
         ("R4 NO au lieu du NO₂", estime(d, y="log_no")),
         ("R5 NO₂ heures de pointe", estime(d, y="log_no2_pointe")),
         ("R6 données mensuelles", estime(g, fe="station + mois")),
         ("R8 fenêtre 2017-2023", estime(d[d.annee <= 2023], phases=("s_p1", "s_p2")))]
rob = pd.DataFrame([(n, e, s) for n, (e, s) in tests], columns=["test", "effet", "se"])
rob.to_csv(OUT / "robustesse.csv", index=False)

fig, ax = plt.subplots(figsize=(9, 5.2))
y = np.arange(len(rob))[::-1]
ax.axvline(0, color=ENCRE2, lw=1)
for yi, (_, r) in zip(y, rob.iterrows()):
    principal = r.test == "Modèle principal"
    col = ROUGE if principal else BLEU
    ax.plot([pct(r.effet - 1.96 * r.se), pct(r.effet + 1.96 * r.se)], [yi, yi], color=ENCRE2, lw=1.5, solid_capstyle="round")
    ax.plot(pct(r.effet), yi, "o", ms=9 if principal else 7, color=col, zorder=3)
    ax.text(31, yi, f"{pct(r.effet):+.1f} %", va="center", ha="right", fontsize=9, color=ENCRE,
            fontweight="bold" if principal else "normal")
ax.set_yticks(y); ax.set_yticklabels(rob.test)
ax.get_yticklabels()[0].set_fontweight("bold")
ax.set_xlim(-25, 32); ax.grid(axis="y", visible=False)
ax.set_xlabel("Effet propre de l'interdiction des Crit'Air 5 (β₂ − β₁, %), IC 95 %")
ax.set_title("Robustesse : le saut est positif dans presque tous les tests", loc="left", fontsize=12, fontweight="bold", color=ENCRE)
fig.text(0.01, -0.02, "R4 (NO) est imprécis : 10 % des jours manquent, 34 % à la station de fond de Strasbourg. IC indicatifs (grappes = stations).",
         color=ENCRE2, fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig4_robustesse.png", dpi=200, bbox_inches="tight"); plt.close(fig)
print(rob.assign(pct=pct(rob.effet)).round(4).to_string()); print("placebos", np.round(pct(pl), 2), "mde", round(pct(mde), 2))
